package com.Paylogic.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaylogicApplicationTests {

	@Test
	void contextLoads() {
	}

}
