package com.Paylogic.demo;

import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.annotation.XmlElementDecl.GLOBAL;

import org.springframework.stereotype.Controller;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hash.logic.ChecksumUtils;

@Controller
public class PaylogicAPI {
	
	String  secret_key = "b4361606c9da45a8";
	
	@RequestMapping("/post")
	public String request(Model request) throws NoSuchAlgorithmException {
		
		
		
Random random=new Random();
		
		int amount = 1200;
		int currency_code = 356;
		String App_id = "1262220128111814";
		int orderno = random.nextInt(100000);
		String email = "user@gmail.com";
		String Name = "Manish";
		String Phone = "9899632630";
		String address = "Delhi";
		String zip = "110032";
		String callback ="http://localhost:8009/response";
		String txnType = "SALE";
		
		
		
		Map<String, Object> map = new HashMap<String, Object>();
        map.put("AMOUNT", amount);
        map.put("CURRENCY_CODE",currency_code); 
        map.put("CUST_EMAIL",email );
        map.put("CUST_NAME",Name );
        map.put("CUST_PHONE",Phone );
        map.put("CUST_STREET_ADDRESS1", address);
        map.put("CUST_ZIP", zip);
        map.put("ORDER_ID",orderno );
        map.put("APP_ID", App_id);
        map.put("RETURN_URL",callback );
        map.put("TXNTYPE", txnType);
		
        ChecksumUtils c = new ChecksumUtils();
        
        String hash	= c.generateCheckSum(map, secret_key);
        		
        System.out.println("REQUEST========" +map);
        System.out.println("HASH========" +hash);
        
		
			
		request.addAttribute("APP_ID",App_id);
		request.addAttribute("ORDER_ID",orderno);
		request.addAttribute("AMOUNT",amount);
		request.addAttribute("TXNTYPE",txnType);
		request.addAttribute("CUST_NAME",Name);
		request.addAttribute("CUST_STREET_ADDRESS1",address);
		request.addAttribute("CUST_ZIP",zip);
		request.addAttribute("CUST_PHONE",Phone);
		request.addAttribute("CUST_EMAIL",email);
		request.addAttribute("CURRENCY_CODE",currency_code);
		request.addAttribute("RETURN_URL",callback);
		request.addAttribute("HASH",hash);
		
		return "request";
	}

	
	
	@PostMapping("/response")
	public String get(Model res,HttpServletRequest request) throws NoSuchAlgorithmException {
		
		String datentime=request.getParameter("RESPONSE_DATE_TIME");
		String time=datentime.replace("+", " ");
		 System.out.println("TIME========" +time);
		
		Map<String, Object> map = new HashMap<String, Object>();
        map.put("RESPONSE_DATE_TIME",time);
        map.put("RESPONSE_CODE", request.getParameter("RESPONSE_CODE"));
        map.put("STATUS", request.getParameter("STATUS"));
        map.put("APP_ID", request.getParameter("APP_ID"));
        map.put("TXN_ID", request.getParameter("TXN_ID"));
        map.put("TXNTYPE",request.getParameter("TXNTYPE"));
        map.put("RETURN_URL", request.getParameter("RETURN_URL"));
        map.put("ORDER_ID", request.getParameter("ORDER_ID"));
        
        
        if(request.getParameter("ACQ_ID") != null ) {
        	map.put("ACQ_ID", request.getParameter("ACQ_ID"));
        };
        if(request.getParameter("CARD_MASK") != null ) {
        	map.put("CARD_MASK", request.getParameter("CARD_MASK"));
        };
        if(request.getParameter("DUPLICATE_YN") != null ) {
        	map.put("DUPLICATE_YN", request.getParameter("DUPLICATE_YN"));
        };
        if(request.getParameter("MOP_TYPE") != null ) {
        	map.put("MOP_TYPE", request.getParameter("MOP_TYPE"));
        };
        if(request.getParameter("PAYMENT_TYPE") != null ) {
        	map.put("PAYMENT_TYPE", request.getParameter("PAYMENT_TYPE"));
        };
        if(request.getParameter("RESPONSE_MESSAGE") != null ) {
        	map.put("RESPONSE_MESSAGE", request.getParameter("RESPONSE_MESSAGE"));
        };
        if(request.getParameter("CUST_PHONE") != null  ) {
        	map.put("CUST_PHONE", request.getParameter("CUST_PHONE"));
        };
        if(request.getParameter("CUST_NAME") != null  ) {
        	map.put("CUST_NAME", request.getParameter("CUST_NAME"));
        };
        if(request.getParameter("CUST_EMAIL") != null ) {
        	map.put("CUST_EMAIL", request.getParameter("CUST_EMAIL"));
        };
        if(request.getParameter("CURRENCY_CODE") != null ) {
        	map.put("CURRENCY_CODE", request.getParameter("CURRENCY_CODE"));
        };
        if(request.getParameter("AMOUNT") != null ) {
        	map.put("AMOUNT", request.getParameter("AMOUNT"));
        };
        if(request.getParameter("RRN") != null ) {
        	map.put("RRN", request.getParameter("RRN"));
        };
        if(request.getParameter("ORIG_TXN_ID") != null ) {
        	map.put("ORIG_TXN_ID", request.getParameter("ORIG_TXN_ID"));
        };
        if(request.getParameter("AUTH_CODE") != null ) {
        	map.put("AUTH_CODE", request.getParameter("AUTH_CODE"));
        };
        
        
        
        ChecksumUtils c = new ChecksumUtils();
        String hash	= c.generateCheckSum(map, secret_key);
		
        System.out.println("REQUEST========" +map);
        System.out.println("HASH========" +hash);
		
        String checksum ="HASH NOT MATCHED";
		if(hash.equals(request.getParameter("HASH"))) {
			checksum ="HASH MATCHED";
		}

		String response = "failed";
		if(request.getParameter("RESPONSE_MESSAGE") !=null) {
			
			 response = request.getParameter("RESPONSE_MESSAGE");
		}
		
		
		
		res.addAttribute("response",response);
		res.addAttribute("ORDER_ID",request.getParameter("ORDER_ID"));
		res.addAttribute("APP_ID",request.getParameter("APP_ID"));
		res.addAttribute("TXN_ID",request.getParameter("TXN_ID"));
		res.addAttribute("time",time);
		res.addAttribute("hash",checksum);
		
        
        
		
		return "response";
	}
	
}
